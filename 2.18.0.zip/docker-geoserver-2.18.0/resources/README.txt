Resources needed in the image at build time should be placed here.
